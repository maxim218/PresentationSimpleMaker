function hideAllBoxes(){
	for(let i = 0; i < 100; i++){
		try {
			$("#slide_" + i).hide();
		} catch (err) {
			// err
		}
	}
}

function showBox(number){
	hideAllBoxes();
	try {
		$("#slide_" + number).show(1500);
	} catch (err) {
		// err
	}
}

let boxNumber = 0;

window.onkeydown = function(event) {	
	const n = event.keyCode;
	if(n === 37){
		boxNumber -= 1;
		showBox(boxNumber);
	}
	if(n === 39){
		boxNumber += 1;
		showBox(boxNumber);
	}
}


